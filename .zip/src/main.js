import express from "express"
import { config } from "dotenv"
import { connectDb } from "./config/db.js"
import router from "./routes/index.route.js"
config()

let port = Number(process.env.PORT)
let app = express()
app.use(express.json())

connectDb()

app.use("/api", router)
app.listen(port, () => console.log(`Server is running on port `, port))