import { Router } from "express";
import controller from "../controllers/author.controller.js"
let router = Router()

export default router
    .post("/", controller.create)