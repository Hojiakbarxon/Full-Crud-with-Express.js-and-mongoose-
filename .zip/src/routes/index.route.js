import authorRouter from "./author.route.js";
import { Router } from "express";

let router = Router()

export default router
    .use("/author", authorRouter)