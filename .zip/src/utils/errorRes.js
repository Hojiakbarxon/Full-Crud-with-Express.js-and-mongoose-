export function errorResponse(res, error) {
    let statusCode = error.statusCode || 500
    let message = error.message || `Internal server error`
    return res.status(statusCode).json({
        statusCode: statusCode,
        message: message
    })
}