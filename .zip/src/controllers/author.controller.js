import Author from '../schemas/author.schema.js'
import { errorResponse } from '../utils/errorRes.js'
import { successRes } from '../utils/successRes.js'

class AuthorController {
    async create(req, res) {
        try {
            let newAuthor = await Author.create(req.body)
            return successRes(res, newAuthor, 201)
        } catch (error) {
            console.log(error)
            return errorResponse(res, error)
        }
    }
}

export default new AuthorController()